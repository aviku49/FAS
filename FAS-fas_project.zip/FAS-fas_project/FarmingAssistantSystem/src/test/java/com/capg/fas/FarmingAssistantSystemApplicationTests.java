package com.capg.fas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmingAssistantSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
