package com.capg.fas.service;

import com.capg.fas.DTO.FarmerDetailsDTO;
import com.capg.fas.beans.FarmerDetails;

public interface IFarmerDetailsService {
	
	public FarmerDetailsDTO addFarmer(FarmerDetails farmer);
	

}
