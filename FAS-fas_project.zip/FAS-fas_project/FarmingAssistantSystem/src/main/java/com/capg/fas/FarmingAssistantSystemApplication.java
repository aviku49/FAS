package com.capg.fas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmingAssistantSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmingAssistantSystemApplication.class, args);
	}

}
