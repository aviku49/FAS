package com.capg.fas.service;

import com.capg.fas.DTO.SupplierDetailsDTO;
import com.capg.fas.beans.SupplierDetails;

public interface ISupplierDetailsService {
	public SupplierDetailsDTO addSupplier(SupplierDetails supplier);

}
