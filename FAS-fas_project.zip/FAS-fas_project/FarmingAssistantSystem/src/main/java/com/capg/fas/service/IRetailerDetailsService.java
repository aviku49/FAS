package com.capg.fas.service;

import com.capg.fas.DTO.RetailerDetailsDTO;
import com.capg.fas.beans.RetailerDetails;

public interface IRetailerDetailsService {

	public RetailerDetailsDTO addRetailer(RetailerDetails retailer);
}
